﻿using UnityEngine;
using System.Collections;

/// <summary>
/// A game without crates is a shitty game. Do not dissapoint the crate god by not having crates in your game.
/// </summary>
public class Crate : WorldEntity {  //ACHTUNG! The : <<--- means that it inheriences from WorldEntity

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
