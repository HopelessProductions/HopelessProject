﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Code.Weapons
{
    public class Weapon : MonoBehaviour
{
        protected float firingSpeed = 1f; //How long to wait after firing
        private float firingCooldown = 0f;

        //Protected means that only classes that inherient from this class, can modify the variables
        //So for us, only Smg3 and RPG can modify weaponDamage
        protected float damage;
        protected float range;
        protected float reloadTime;

        //However, do still allow other classes to see what the damage and range is, we can use Getter functions
        //Simply name them the same thing, but use a Capital letter
        public float Damage { get { return damage; } }
        public float Range { get { return range; } }
        public float FiringSpeed { get { return firingSpeed; } }


        //You can also do fancy stuff like
        public float ReloadTime { get { return reloadTime; } set { reloadTime = value / 2; } }

        /*
        Getters and setters are nice, so that instead of having everything public, we make sure that only classes that should be allowed to change variables,
        Can do that,
        instead of letting the SexyPlayer change the weaponRange by mistake and then you'd go debugging and wonder why the fuck the weaponRange is 2 when it says in Smg3 that its 1000
        */

        void Start()
        {
            SetStats();
        }


        protected virtual void SetStats()
        {

        }

        void Update()
        {
            if (firingCooldown > 0)
            {
                /*
                Time.deltaTime gives us the time since the last frame
                So it'll be something like 1 * 0.016, if we don't do this machines with higher fps will fire faster. Trickster would love it.
                */
                firingCooldown -= 1 * Time.deltaTime;
                if (firingCooldown < 0)
                {
                    firingCooldown = 0;
                }
            }
        }

        /// <summary>
        /// Pew pew! (If you want fancy comments like these, just type ///
        /// and this text will show up when you look at this function. 
        /// Like move your mouse over the Shoot(); in the Update function
        /// </summary>
        public void Shoot(Transform playerTransform)
        {
            if (firingCooldown > 0)
            {
                //Skip the code below if we aren't allowed to fire
                return;
            }

            firingCooldown = firingSpeed;
            //Debug.Log("Pew Pew");


            //Do raytrace magic here
            RaycastHit objectHit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            Vector3 playerDirection = playerTransform.TransformDirection(Vector3.forward);

            //the out means that we set the objectHit variable
            //and the Physics.Raycast returns a true if we hit something
            if (Physics.Raycast(playerTransform.position, playerDirection, out objectHit, range)) //Yay we hit something
            {
                //Debug.Log("Yay we hit something!");
                objectHit.transform.SendMessageUpwards("TakeDamage", damage, SendMessageOptions.DontRequireReceiver); //Apparently there is this cool function!
            }
        }
    }
}

