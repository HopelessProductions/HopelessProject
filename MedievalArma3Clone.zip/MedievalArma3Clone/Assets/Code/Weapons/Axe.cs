﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Code.Weapons
{
    public class Axe : Weapon
    {
        public void Start()
        {
            damage = 100;
            range = 2;
            firingSpeed = 0.20f;
            
        }
    }
}


