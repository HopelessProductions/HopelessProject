﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Code.Weapons
{
    public class WeaponRPG : Weapon
    {
        protected override void SetStats()
        {
            damage = 75;
            range = 500;
            firingSpeed = 2f;
        }
    }
}