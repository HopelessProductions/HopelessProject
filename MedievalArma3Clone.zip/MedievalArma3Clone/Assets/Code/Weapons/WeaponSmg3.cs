﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Code.Weapons
{
    public class WeaponSmg3 : Weapon
    {
        public void Start()
        {
            damage = 1;
            range = 50;
            firingSpeed = 0.20f;
        }
    }
}

