﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Code.Movement
{
    public class PlayerMovement
    {

        private float m_WalkSpeed;
        private bool m_IsWalking;
        private float m_RunSpeed;
        private float m_YRotation;
        private Vector2 m_Input;
        private Vector3 m_MoveDir = Vector3.zero;
        private CharacterController m_CharacterController;
        private float m_StickToGroundForce;
        private float m_GravityMultiplier;
        private CollisionFlags m_CollisionFlags;
        private MouseLook m_MouseLook;

        private Camera m_Camera;
        private Vector3 m_OriginalCameraPosition;

        private Transform playerTransform;

        //Look a constructor, oooh soo shinnnnny
        public PlayerMovement(Transform transform, CharacterController characterController, Camera cameraMain)
        {
            this.playerTransform = transform;

            m_CharacterController = characterController;
            m_Camera = cameraMain;
            m_OriginalCameraPosition = m_Camera.transform.localPosition;
            //m_FovKick.Setup(m_Camera);
            //m_HeadBob.Setup(m_Camera, m_StepInterval);
            //m_StepCycle = 0f;
            //m_NextStep = m_StepCycle / 2f;
            m_MouseLook = new MouseLook(transform, m_Camera.transform);
            m_WalkSpeed = 4;
        }

        public void Update()
        {
            UpdateMovement();
            m_MouseLook.UpdateCursorLock();
            RotateView();
        }

        private void UpdateMovement()
        {
            float speed = GetMovement();

            // always move along the camera forward as it is the direction that it being aimed at
            Vector3 desiredMove = playerTransform.forward * m_Input.y + playerTransform.right * m_Input.x;

            // get a normal for the surface that is being touched to move along it
            RaycastHit hitInfo;
            Physics.SphereCast(playerTransform.position, m_CharacterController.radius, Vector3.down, out hitInfo,
                               m_CharacterController.height / 2f, Physics.AllLayers, QueryTriggerInteraction.Ignore);
            desiredMove = Vector3.ProjectOnPlane(desiredMove, hitInfo.normal).normalized;

            m_MoveDir.x = desiredMove.x * speed;
            m_MoveDir.z = desiredMove.z * speed;


            if (m_CharacterController.isGrounded)
            {
                m_MoveDir.y = -m_StickToGroundForce;
            }
            else
            {
                m_MoveDir += Physics.gravity * m_GravityMultiplier * Time.fixedDeltaTime;
            }
            m_CollisionFlags = m_CharacterController.Move(m_MoveDir * Time.fixedDeltaTime);


            UpdateCameraPosition(speed);

        }

        private float GetMovement()
        {
            float speed = 3;
            // Read input
            float horizontal = Input.GetAxis("Horizontal");
            float vertical = Input.GetAxis("Vertical");
            bool waswalking = m_IsWalking;

            // set the desired speed to be walking or running
            speed = m_IsWalking ? m_WalkSpeed : m_RunSpeed;
            m_Input = new Vector2(horizontal, vertical);

            // normalize input if it exceeds 1 in combined length:
            if (m_Input.sqrMagnitude > 1)
            {
                m_Input.Normalize();
            }
            return speed;
        }

        private void UpdateCameraPosition(float speed)
        {
            //Vector3 newCameraPosition;
            //m_Camera.transform.localPosition = newCameraPosition;
        }


        private void RotateView()
        {
            m_MouseLook.LookRotation(playerTransform, m_Camera.transform);
        }
    }
}
