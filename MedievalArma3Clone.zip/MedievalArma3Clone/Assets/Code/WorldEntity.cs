﻿using UnityEngine;
using System.Collections;
using System;

public class WorldEntity : MonoBehaviour {

    public float healthMax;
    public float healthCurrent;
    public string Name;
    private Boolean isDead = false;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    /// <summary>
    /// Typing virtual before the function type in a function,
    /// allows us to change that function in the classes that inherience from this class.
    /// 
    /// So that the Tree can bleed bark and the SexyPlayer can gain health.
    /// </summary>
    /// <param name="damage"></param>
    public virtual void TakeDamage(float damage)
    {
        Debug.Log(Name + " took " + damage + " damage.");
        if ((healthCurrent -= damage) <= 0 && isDead == false)
        {
            Debug.Log(Name + " is now dead.");
            isDead = true;
            MeshRenderer meshRenderer = GetComponent<MeshRenderer>();
            if (meshRenderer != null)
            {
                meshRenderer.enabled = false;
            }
            GameObject.Destroy(this);
            //Ouchie ouchie do magic here!

            
        }
    }
}
