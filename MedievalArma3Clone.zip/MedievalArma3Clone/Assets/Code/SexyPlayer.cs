﻿using UnityEngine;
using System.Collections;
using Code.Movement;
using Code.Weapons;

public class SexyPlayer : WorldEntity {

    //These are defined in the scene
    public Weapon weaponEquipped; //We have a Smg3 equipped, but we can treat it as a weapon, since it inheriences from weapon. COOL HUH?! :D

    //Movement
    private PlayerMovement playerMovement;


    // Use this for initialization
    void Start () {

        CharacterController characterController = GetComponent<CharacterController>();

        playerMovement = new PlayerMovement(this.transform, characterController, Camera.main);
	}
	
	// Update is called once per frame
	void Update () {

        playerMovement.Update();

        if (weaponEquipped != null)
        {
            //weaponEquipped.Update();
            if (Input.GetButton("Fire1")) //always have if (){ } , don't do it with just if (), it'll help you later on.
            {
                weaponEquipped.Shoot(this.transform);
            }
        }
    }

    /*To override a function that is virtual, all ya have to do is type: ov, press arrowkeydown, press space
    and all the functions you can ovveride should show up (those that are virtual)
    */
    public override void TakeDamage(float damage) 
    {
        base.TakeDamage(damage); //Calling base tells the baseclass to do it's thing, it can be called first or last or in the middle of the function.

        if (this.healthCurrent > 0)
        {
            //The player likes getting hurt, so if it survives the damage, it heals itself for half
            this.healthCurrent += damage / 2;
        }
    }  
}

